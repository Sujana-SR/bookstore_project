package com.example.demo.Controller;

import com.example.demo.Entity.Product;
import com.example.demo.Entity.Register;
import com.example.demo.Entity.Userdetails;
import com.example.demo.Repoistory.RegisterRepository;
import com.example.demo.Repoistory.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;

@Controller
public class Controllers {

    @Autowired
    UserRepository userRepository;

    @Autowired
    RegisterRepository registerRepository;

    @GetMapping("/index")
    public String index() {
        return "index";
    }

    @GetMapping("/About")
    public String about() {
        return "About";
    }

    @GetMapping("/account")
    public String account() {
        return "account";
    }

    @RequestMapping("/register")
    public String Register(Register register) {
        registerRepository.save(register);

        return "Login";
    }

    @RequestMapping("signup")
    public String signup() {
        return "Register";
    }

    @RequestMapping("signup1")
    public String signup1() {
        return "Register";
    }

    @GetMapping("/detail")
    public String details() {
        return "detail";
    }

    @GetMapping("/welcome")
    public String welcome() {
        return "welcome";
    }

    @GetMapping("/read")
    public String read() {
        return "read";
    }

    @RequestMapping("/save")
    public String save(Userdetails userdetails) {
        userRepository.save(userdetails);
        return "success";
    }

}
